import React, { useState } from "react";
import Footer from "./common/Footer";
import Navbar from "./common/Navbar";
import { useNavigate } from "react-router-dom";
import Swal from 'sweetalert2';
import axios from "axios";
import {DNA} from 'react-loader-spinner';


function NotEligible() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [errors, setErrors] = useState({});
  const [wait, setWait] = useState(false);

  function validateForm() {
    const newErrors = {};

    if (!name.trim()) {
      newErrors.name = "*Name is required.";
    } else if (/\d/.test(name)) {
      newErrors.name = "Name should not contain numbers.";
    } else if (name.length < 2) {
      newErrors.name = "Name must be at least 2 characters long.";
    }
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.trim()) {
      newErrors.email = "*Email is required.";
    } else if (!emailPattern.test(email)) {
      newErrors.email = "Invalid email format.";
    }

    return newErrors;
  }

  function handleFormSubmit(event) {
    event.preventDefault();
    const newErrors = validateForm();

    if (Object.keys(newErrors).length === 0) {
      console.log("Form submitted with:", { name, email });
      submitFormData();
    } else {
      setErrors(newErrors);
    }
  }

  async function submitFormData() {
	try{
	  const response = await axios.post(`https://orders.newdaydiagnostics.com/api/v1/manage/noteleg-info-submit`, {
		  	name: name,
		  	email: email,
		  });

		if(response.status === 200){
			Swal.fire({
  position: "center",
  icon: "success",
  title: "You will recieve an email shortly!",
  showConfirmButton: false,
  timer: 1500
});
setName("");
setEmail("");
		}
	}catch (err){
	  console.log(err);
	}
  }


  async function downloadInformationPDF() {
                try {
			setWait(true);
                        const response = await axios.get(`https://orders.newdaydiagnostics.com/api/v1/manage/download-info-noteleg`, {
                                responseType: 'blob',
                        });
                        const contentDisposition = response.headers['content-disposition'];
                        let filename = 'More_Information_Eligibility.pdf'; // Default filename
                        if (contentDisposition) {
                                const match = contentDisposition.match(/filename="?([^"]+)"?/);
                                if (match) {
                                        filename = match[1];
                                }
                        }
                        const blob = new Blob([response.data], { type: 'application/pdf' });
                        saveAs(blob, 'More_Information_Eligibility.pdf');
			setWait(false);
                } catch (err) {
			setWait(false);
                        console.log(err);
                }     
  }



  return (
    <>
      <Navbar />
      <section className="py-[125px] not-eligible-page">
        <div className="center-wr flex flex-col items-center">
          <figure onClick={() => navigate("/")} className="cursor-pointer">
            <img src="/coloHealthNoShadowLogo.png" width={240} alt="" />
          </figure>
          <h1 className="text-[40px] font-semibold text-center">
            We are sorry, you do not qualify at this time.
          </h1>
          <div className="w-[75%]">
            <p className="font-medium text-[18px] mt-[40px] text-center">
              The results of your health history suggest ColoHealth may not be
              indicated for you.
            </p>
            <p className="font-medium text-[18px] mt-[40px] text-center">
              Your health and safety are of the utmost importance to us,
              therefore ordering it directly through our website and under the
              supervision of our telehealth physician is not possible. However,
              your doctor understands the possible risks and benefits of
              ColoHealth for you. We recommend you speak with them about whether
              ColoHealth is right for you.{" "}
            </p>
            <p className="font-medium text-[18px] mt-[40px] text-center">
              For your convenience, information about this screening test can be
              downloaded through this link. You may also provide your contact
              information and we will send you an email with the information
              attached.
            </p>
            <div className="text-center mt-[40px]">
              <button onClick={downloadInformationPDF}  className="bg-slate-900 text-white leading-[50px] px-[15px]">
		{
		wait  ? (
		<DNA
  visible={true}
  height="50"
  width="50"
  ariaLabel="dna-loading"
  wrapperStyle={{}}
  wrapperClass="dna-wrapper"
  />
		):('DOWNLOAD')
		}
	  </button>
            </div>
            <div className="text-center mt-[40px] not-eligible-form">
              <h3>GET MORE INFORMATION</h3>
              <form onSubmit={handleFormSubmit}>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="NAME*"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                  {errors.name && (
                    <span
                      style={{
                        color: "red",
                        position: "absolute",
                        left: "0",
                        bottom: "-21px",
                        fontSize: "14px",
                      }}
                    >
                      {errors.name}
                    </span>
                  )}
                </div>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="EMAIL*"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                  {errors.email && (
                    <span
                      style={{
                        color: "red",
                        position: "absolute",
                        left: "0",
                        bottom: "-21px",
                        fontSize: "14px",
                      }}
                    >
                      {errors.email}
                    </span>
                  )}
                </div>
                <div>
                  <button type="submit" className="not-eligible-download-btn">
                    CONNECT
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}

export default NotEligible;
