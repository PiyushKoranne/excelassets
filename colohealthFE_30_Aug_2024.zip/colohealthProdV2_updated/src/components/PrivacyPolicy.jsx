import React, {useEffect} from "react";
import Navbar from "./common/Navbar";
import Footer from "./common/Footer";

function PrivacyPolicy(){

	useEffect(()=>{
		window.scrollTo({
  			top: 0,
  			left: 0,
  			behavior: "smooth",
		})
	})
  return(
    <>			
  <Navbar />
  <section className='home-banner-wr privacy-policy py-[50px]'>
  <div className='center-wr'>
    <div>
			 		<h1 className='text-[40px] text-[#606163]  font-[500] uppercase text-left'>New Day Diagnostics Privacy Policy</h1>
          <p className="text-[#606163] text-[16px] leading-[26px] py-[5px] font-[500]">This site is owned and operated by New Day Diagnostics. We consider your privacy on the Internet to be paramount. At New Day, we want to make your experience online satisfying and safe. Because we gather certain types of information about our users, we feel you should fully understand the terms and conditions surrounding the capture and use of that information. This privacy statement discloses what information we gather and how we use it.</p>
    </div>
    <div>
      <h4 className='pt-[64px] pb-[25px] text-[18px] text-[#606163] font-[600] '>EDP GATHERS AND TRACKS two types of information about users:</h4>

      <ul className="text-[#606163]" style={{listStyle:"disc",marginLeft:"20px",lineHeight:"26px"}}>
        <li>Information that users provide through optional, voluntary submissions. These are voluntary  submissions to receive New Day information, contacting us, and from participation in polls and surveys.</li>
        <li>Information New Day gathers through aggregated tracking information derived mainly by tallying page views throughout our sites. This information allows us to better tailor our content to readers’ needs and to help our advertisers and sponsors better understand the demographics of our audience. Under no circumstances does New Day divulge any information about an individual user to a third party.</li>
      </ul>
    </div>
    <div className="">
      <h3 className="pb-[25px] pt-[25px] text-[34px] text-[#606163]  font-[500]">New Day Diagnostics Web Site Usage Policy</h3>
      <p className="text-[#606163]">YOUR CONSENT: By using this site, you consent to the collection and use of this information by New Day. If we decide to change our privacy policy, we will post those changes on this page so that you are always aware of what information we collect, how we use it, and under what circumstances we disclose it.</p>
    </div>
    
          </div>
</section>
<Footer />
    </>
  )
}

export default PrivacyPolicy;
