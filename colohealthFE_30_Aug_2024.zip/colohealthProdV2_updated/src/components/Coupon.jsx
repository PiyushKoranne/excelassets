import React from "react";

function Coupon({couponData}) {
	return (
		<div className="coupon-particle-data-container">
			<div className='coupons-part-parent-wr yellow' style={{ background: "#DEA52B" }}>
				<div className="particles-wr">
					<span></span>
					<span></span>
					<span></span>
					<span></span>
					<span></span>
					<span></span>
					<span></span>
				</div>
				<div className='coupon-card-wr-left'>
					<span style={{ fontWeight: "600", letterSpacing: "3px", color: "#fff" }}>SHOPPING COUPON</span>
					<span className='discount-percentage'>{couponData.couponDiscount}%</span>
				</div>
				<div className="coupon-card-wr-right" style={{ textAlign: "center" }}
				><span style={{ fontWeight: "600" }}>{couponData.couponName}</span><span style={{ fontWeight: "600", fontSize: "35px" }}>{couponData.couponCode}</span><span>
		ColoHealth Dicount</span></div>
				<div className="particles-wr right">
					<span></span>
					<span></span>
					<span></span>
					<span></span>
					<span></span>
					<span></span>
					<span></span>
				</div>
				<div className="particles-wr center-white">
					<span></span>
					<span></span>
					<span></span>
					<span></span>
					<span></span>
					<span></span>
					<span></span>
				</div>
				<div className="particles-wr center-white black">
					<span></span>
					<span></span>
					<span></span>
					<span></span>
					<span></span>
					<span></span>
					<span></span>
				</div>
			</div>


		</div>
	)
}

export default Coupon;
