import React from "react";
import { useWindowSize as useWindowSizeD } from "@react-hook/window-size";
import {Popconfirm, Button} from "antd";
import { FaPhone } from "react-icons/fa6";

function NeedHelp() {

	const [widthD, heightD] = useWindowSizeD();


  return (
	
		widthD > 768 ? (
			<div className="need-help-call-wr z-[100] text-[20px] font-semibold shadow-xl text-black fixed bottom-[40px] right-[50px] bg-[#E6E7E8] border-[4px] border-[#DEA52B] py-[10px] px-[30px] flex flex-col items-center justify-center">
      <div className="dekstop-help-call">
        <p className="">Need Help? Call</p>
        <a href="tel:865-299-6250" className="">
          865-299-6250
        </a>
      </div>
      <div className="phone-help-call">
        <i class="fa-solid fa-phone"></i>
      </div>
    </div>
		)
	:(
		<Popconfirm
			className="contact-popconfirm"
            		placement="left"
            		title={"Need Help?"}
            		description={<p>Call <a href="tel:865-299-6250" >865-299-6250</a></p>}
            		okText="Okay"
            		cancelText={false}
          	>
            <button className="z-[100] fixed bottom-[32px] right-[15px] flex items-center justify-center p-[5px] h-[50px] w-[50px] rounded-full shadow-[0px_0px_12px_5px_rgba(237,104,62,0.3)] bg-[#ED683E] text-white"><FaPhone /></button>
          </Popconfirm>	
	) 
  );
}

export default NeedHelp;
