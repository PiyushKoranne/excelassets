echo "building and deploying...";
npm run build;
mv ../../server/coloheal
