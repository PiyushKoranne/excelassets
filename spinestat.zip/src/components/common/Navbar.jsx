import axios from 'axios';
import React, { useEffect } from 'react'
import { FaRegUser } from 'react-icons/fa';
import { Link, useNavigate } from 'react-router-dom';
import { Dropdown,Button } from 'antd';


function Navbar() {
	const navigate = useNavigate();
	const at = localStorage.getItem("colo_H_accessToken");
	const [isProvider, setIsProvider] = React.useState(false);
	const [providerData, setProviderData] = React.useState({});

	const items = [
		{
			label: 'Sign Out	',
			key: 'SIGN OUT',
		},
	];

	function onNavClick({ key }) {
		switch (key) {
			case "ABOUT":
				console.log("About us nav event");
				break;
			case "VIEW SETTINGS":
				console.log("View settings nav event");
				break;
			case "SIGN OUT":
				console.log("Signing out");
				localStorage.removeItem("colo_H_accessToken");
				localStorage.removeItem("colo_H_providerData");
				navigate("/");
				window.location.reload();
				break;
		}
	} 

	function modifyArrayByLogin(arr) {
		arr.push({
			key: '5',
			label: (
				<Link onClick={()=>{handleLogout()}}>
					SIGN OUT
				</Link>
			),
		});
		return arr;
	}

	function handleLogout() {
		console.log("Signing out");
		localStorage.removeItem("colo_H_accessToken");
		localStorage.removeItem("colo_H_providerData");
		if(window.location.pathname === "/"){
			window.location.reload();
		}else {
			navigate("/");
		}
}

	async function verifyAccessToken() {
		try {
			const response = await axios.post("https://spinestat.newdaydiagnostics.com/api/v1/manage/verify", { accessToken: at });
			if (response.status === 200) {
				setIsProvider(true);
				setProviderData(JSON.parse(localStorage.getItem("colo_H_providerData")))
			} else {
				localStorage.removeItem("colo_H_accessToken");
				localStorage.removeItem("colo_H_providerData");
			}
		} catch (error) {
			console.log(error);
			localStorage.removeItem("colo_H_accessToken");
			localStorage.removeItem("colo_H_providerData");
		}
	}

	const responsive_items = [
		{
			key: '1',
			label: (
				<Link to="/">
					Sign Up / Sign In
				</Link>
			),
		},
	];

	
	

	useEffect(() => {
		if (at) {
			verifyAccessToken();
		}
	}, [at])

	return (
		<nav id='navbar-id' className='navbar-wr'>
			<div className='center-wr flex items-center justify-between  border-b-[4px] border-b-[#DEA52B]'>
				<figure className='colo-health-logo-wr cursor-pointer w-[30%]' onClick={()=>navigate("/")}>
					<img src="/NewDayLogo_FINAL.png"  className='pt-[10px]' alt="" />
				</figure>
				<div className=''>
					<ul className='responsives-nav-menu flex items-center justify-end gap-[27px] list-none py-[20px]'>
						<li onClick={()=>navigate("/")} className='uppercase text-slate-500 font-semibold text-[14px] cursor-pointer transition-all duration-300 border-b-[2px] border-b-transparent hover:border-b-slate-500'>Sign up / Sign in</li>
						{isProvider && <li className='uppercase text-slate-500 font-semibold text-[14px] cursor-pointer pr-[10px]'>
							<Dropdown
								menu={{
									items,
									onClick: onNavClick,
								}}
							><FaRegUser size={24} /></Dropdown>
						</li>}
					</ul>

					<div className='responsives-nav-menu'>
					<Dropdown
        menu={{
          items:isProvider ? modifyArrayByLogin(responsive_items) : responsive_items,
        }}
        placement="bottomRight"
        arrow
      >
        <Button><img className='mt-[9px]' src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAExJREFUSEtjZKAxYKSx+QyjFhAM4QEJov8EnYVfAYqjsfmA5hZQ6AFU7QMSBzT3Ac3jgOYW0DyIhr4FNI8Dmlsw9ONg1AcoIUDz0hQAbegGGXzv/l0AAAAASUVORK5CYII="/></Button>
      </Dropdown>

					</div>
				</div>
			</div>
		</nav>
	)
}

export default Navbar
