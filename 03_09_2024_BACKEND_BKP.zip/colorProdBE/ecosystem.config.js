module.exports = {
  apps:[
          {
                  name:'ColoHealth Backend',
                  script:'node',
                  args:'index.js',
                  env:{
                          NODE_ENV:'production'
                  },
                  watch:false,
          },
  ],
}

