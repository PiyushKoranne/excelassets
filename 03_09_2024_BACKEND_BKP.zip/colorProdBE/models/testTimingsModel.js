const mongoose = require("mongoose");

const TestTimingsSchema = new mongoose.Schema({
	        notEligiblePDFName: String
})

const testTimingsModel = mongoose.model("Customization", TestTimingsSchema);

module.exports = testTimingsModel;
