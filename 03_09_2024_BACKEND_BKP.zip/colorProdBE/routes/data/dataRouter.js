const express = require("express");
const router = express.Router();
const pageController = require('../../controllers/pageController');
const dataController = require("../../controllers/manageController");
const uploader = require("../../middlewares/fileUploader");
const { verifyUserLogin, verifyAdmin, verifyLogin } = require("../../middlewares/verifyLogin");
const testOrdersModel = require("../../models/testOrderModel");
const providerModel = require("../../models/providerModel");
const upload = require("../../middlewares/fileUploader");
const { registrationHTML } = require("../../config/constants");
const { sendMail } = require("../../config/mailerConfig");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const fs = require('fs');
const path = require('path');
const getAnAcceptPaymentPage = require("../../config/formTokenConfig");
const XLSX = require('xlsx');
const postModel = require("../../models/postModel");
const { getNextOrderId } = require("../../utils/utilFunctions");
const customizationModel = require("../../models/customizationModel");
const {couponModel} = require("../../models/couponModel");
const nodemailer = require("nodemailer");

function fillOrderDetails(orderData) {
  // Path to your existing Excel file
  const filePath = path.join(__dirname, '../../excel_data/orders.xls');

  // Read the Excel file
  const workbook = XLSX.readFile(filePath);

  // Get the first worksheet
  const sheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[sheetName];

  // Find the next empty row in the worksheet
  const range = XLSX.utils.decode_range(worksheet['!ref']);
  let nextRow = range.e.r + 1;

  for (let R = range.s.r; R <= range.e.r; R++) {
    let empty = true;
    for (let C = range.s.c; C <= range.e.c; C++) {
      const cell_address = { c: C, r: R };
      const cell_ref = XLSX.utils.encode_cell(cell_address);
      if (worksheet[cell_ref]) {
        empty = false;
        break;
      }
    }
    if (empty) {
      nextRow = R;
      break;
    }
  }

  // Mapping of backend data to Excel columns
  const columnMapping = {
    'orderId': ['A'],
    'status': ['B'], // set
    'orderDate': ['C'], // set
    'firstName': ['E', 'O'],
    'lastName': ['F', 'P'],
    'streetAddress': ['H', 'Q'],
    'city': ['I','R'],
    'state': ['J','S'],
    'zip': ['K','T'],
    'countryCode': ['L','U'], // set
    'email': ['M'],
    'phone': ['N'],
    'dob': ['AB'],
    'gender': ['AD'],
    'race': ['AE'],
    'ethnicity': ['AF'],
    'paymentMethod': ['AN'], // set
    'productItemNumber': ['AQ'], // set
    'productItemName': ['AR'], // set
    'productPrice': ['AT','AW', 'AY']
  };

  
   // Fill the worksheet with order data
  Object.keys(orderData).forEach((key) => {
    if (columnMapping[key]) {
      columnMapping[key].forEach((column) => {
        const cellAddress = column + (nextRow + 1); // Adjust for 0-based index
        worksheet[cellAddress] = { v: String(orderData[key]), t: 's' }; // Assuming all data is string
      });
    }
  });

  // Update the worksheet range
  worksheet['!ref'] = XLSX.utils.encode_range(range.s, { c: range.e.c, r: nextRow });


  // Write the updated workbook to a new file or overwrite the existing file
  XLSX.writeFile(workbook, filePath);
  console.log("Data added to Excel Sheet");
}

// fetching data routes

// get already scheduled times
router.post("/booked-timings", dataController.getBookedTimingsByMonth);


router.get("/colo-pay", (req, res) => {
	console.log("Generating a form token");
	getAnAcceptPaymentPage((response) => { res.status(200).json({ code: response }); console.log("RESPONSE", response) });
})

router.post("/check-coupon", async (req, res) => {
	try{
		const {couponCode} = req.body;
		const match = await couponModel.findOne({couponCode}).lean();
		if(!match) return res.status(400).json({success: false, message:"Invalid coupon code"});
		return res.status(200).json({...match});
	} catch(err) {
		console.log(err);
		res.status(500).json({success: false, err})
	}
})


router.post("/verify-payment", async (req, res) => {
	try {
		const { pv, regId } = req.body;
		const match = await testOrdersModel.findOne({ _id: regId });
		if (!match) return res.status(400).json({ success: true, msg: "bad request, no match found" });
		if (match.paymentInformation.paymentVerificationHash !== pv) {
			return res.status(400).json({ success: true, msg: "bad request, no verification token found" });
		}
		const decoded = await jwt.verify(match.paymentInformation.paymentVerificationHash, "Test101Credentials");
		if (!decoded || decoded.regId !== match._id.toString()) return res.status(400).json({ success: true, msg: "bad request, verification token invalid" });
		await testOrdersModel.findOneAndUpdate({ _id: regId }, {
			$set: {
				'paymentInformation.status': "COMPLETED",
				'paymentInformation.transactionId': "COMPLETED__" + match._id.toString(),
				'paymentInformation.paymentVerificationHash': "COMPLETED",
				paymentConfirmed: true,
				orderConfirmation: true,
			}
		})

		// add data to the excel sheet 
		const post = await postModel.findOne({_id: match.productId});

		let orderData = await testOrdersModel.findOne({_id: regId}).lean();
		orderData.status = "Processing";
		orderData.orderDate = new Date().toLocaleString();
		orderData.countryCode = "US";
		orderData.productItemNumber = "1";
		orderData.productItemName = post ? post.postData.productName: "";
                orderData.productPrice = post ? post.postData.productPrice : "";
		orderData.paymentMethod = orderData.isInvoiced ? "INVOICE":"ONLINE";
		fillOrderDetails(orderData);
		return res.status(200).json({ success: true, data: { scheduledAt: match.scheduledAt } });

	} catch (error) {
		console.log(error);
		res.status(500).json({ success: false, error })
	}
})

// route for getting invoiced orders 
// route for getting independent orders


router.post("/register-new-test-data", upload.any(), async (req, res) => {
	try {
		console.log("Registration data", req.body);
		const count = await testOrdersModel.countDocuments();
		const nextId = await getNextOrderId();

		const { providerId } = req.body;
		let checkProvider = false;
		let checkInvoice = false;
		let hasCoupon = false;
		let hasDiscount = false;
		if (providerId && providerId !== "undefined") {
			const providerMatch = await providerModel.findOne({ _id: providerId });
			if (providerMatch) checkProvider = true;
			if(req.body.isInvoiced && req.body.isInvoiced === 'true') checkInvoice = true;
		}

		if(!checkProvider){
		    if(req.body.coupon){
			hasCoupon = true;
		    }
		}

		const post = await postModel.findOne({postType:"669a3a1f348f5b66bf71bfe2", postName:"ColoHealth"});
		console.log("########################\n\n",post);
		if(!post) return res.status(400).json({success: false, msg:"Product not found to place order"});
		let amount = post.postData.productPrice;
		// if has discount then process discount first

		if(hasCoupon){
		    const productPrice = post.postData.productPrice;
		    const couponMatch = await couponModel.findOne({couponCode: req.body.coupon});
		    if(couponMatch){
			const discount = productPrice * (couponMatch.couponDiscount/100);
			const max = couponMatch.maximumAllowedDiscount;
			if(max) amount = discount >= max ? productPrice-max : productPrice-discount;
			else amount = productPrice-discount;
			hasDiscount = true;
		    } else {
			hasDiscount = false;
			amount = productPrice
		    }
		}

		const newRegistration = new testOrdersModel({
			providerId: (req.body.providerId && checkProvider) ? req.body.providerId : 'NULL',
			orderId: nextId,
			firstName: req.body.firstName,
			lastName: req.body.lastName,
			streetAddress: req.body.streetAddress,
			city: req.body.city,
			state: req.body.state,
			zip: req.body.zip,
			phone: req.body.phone,
			email: req.body.email,
			dob: req.body.dob,
			gender: req.body.gender,
			race: req.body.race,
			ethnicity: req.body.ethnicity,
			registrationConsent: req.body.confirm,
			scheduledAt: req.body.scheduledAt,
			orderConfirmation: (checkInvoice && checkProvider) ? true : false,
			isInvoiced: checkInvoice,
			productId:post._id,
			productName: post.postData.productName,
			paymentConfirmed: (checkInvoice && checkProvider) ? true : false,
			paymentInformation: {
				status: "PENDING",
				amount,
				hasDiscount,
				productPrice: post.postData.productPrice,
				couponUsed: hasDiscount ? req.body.coupon : "NULL", 
				transactionId: (checkInvoice && checkProvider) ? "INVOICED" : "PENDING",
			}
		});
		await newRegistration.save();

		// created a payment verificatyion token for future
		const paymentVerificationToken = await jwt.sign({ regId: newRegistration._id }, "Test101Credentials");
		await testOrdersModel.findOneAndUpdate({ _id: newRegistration._id }, {
			$set: {
				'paymentInformation.paymentVerificationHash': paymentVerificationToken
			}
		});

		// rename the pdf as it came from frontend
		if (req.body.providerId) {
			const oldPath = path.join(__dirname, "../../recforms", req.files[0].filename);
			const newPath = path.join(__dirname, "../../recforms", `PROV_${req.body.providerId}_${req.body.firstName}_${req.body.lastName}_${newRegistration._id.toString()}_${req.files[0].originalname}`);
			fs.renameSync(oldPath, newPath);
			console.log("Req form pdf saved and renamed");
		}

		if(checkInvoice){
			let orderData = await testOrdersModel.findOne({_id: newRegistration._id}).lean();
  	                orderData.status = "Processing";
                	orderData.orderDate = new Date().toLocaleString();
                	orderData.countryCode = "US";
                	orderData.productItemNumber = "1";
  	               	orderData.productItemName = post.postData.productName;
			orderData.productPrice = post.postData.productPrice;
			orderData.paymentMethod = orderData.isInvoiced ? "INVOICE":"ONLINE";
                	fillOrderDetails(orderData);
			return res.status(200).json({ regid: newRegistration._id })
		}
		
		// generate a payment token
		!checkInvoice && getAnAcceptPaymentPage((error, response) => {
			if (error) {
				throw error;
			} else {
				res.status(200).json({ code: response.token, regid: response.regid })
			}
		}, newRegistration._id, paymentVerificationToken, amount);

	} catch (error) {
		console.log(error);
		res.status(500).json({ success: false, error })
	}
})

router.get("/download-rec-rpt", async (req, res) => {
	try {
		const orderId = req.query.oid;
		const providerId = req.query.pid;
		console.log("DOWNLOADING SCRIPT", req.query);
		if(!orderId || !providerId) return res.status(400).json({success: false, msg:"order id/provider id not found"});
		const orderMatch = await testOrdersModel.findOne({_id: orderId});
		if(!orderMatch) return res.status(400).json({success: false, msg:"order not found"});

		const directoryPath = path.join(__dirname,"../../recforms");
		const files = fs.readdirSync(directoryPath);
		const requiredFile = files.filter(file => file.startsWith(`PROV_${providerId}_${orderMatch.firstName}_${orderMatch.lastName}_${orderId}`))[0];
		const filePath = path.join(__dirname,"../../recforms", requiredFile);
		console.log(filePath)
		res.download(filePath, requiredFile, (err) => {
			if (err) {
				console.error('Error downloading the file:', err);
				res.status(500).send('Error downloading the file.');
			}
		});
	} catch (error) {
		console.log(error);
		res.status(500).json({ success: false, error });
	}
})

router.get("/download-welcome-pdf", async (req, res) => {
        try {
                const providerId = req.query.pid;
                console.log("DOWNLOADING SCRIPT", req.query);
                if(!providerId) return res.status(400).json({success: false, msg:"order id/provider id not found"});
	
		const customizationData = await customizationModel.findOne({});


 

                const directoryPath = path.join(__dirname,"../../recforms");
                const files = fs.readdirSync(directoryPath);
                const requiredFile = files.filter(file => file.startsWith(`${customizationData.portalWelcomePDF}`))[0];
                const filePath = path.join(__dirname,"../../recforms", requiredFile);
                console.log(filePath)
                res.download(filePath, requiredFile, (err) => {
                        if (err) {
                                console.error('Error downloading the file:', err);
                                res.status(500).send('Error downloading the file.');
                        }
                });
        } catch (error) {
                console.log(error);
                res.status(500).json({ success: false, error });
        }
})

router.get("/download-info-noteleg", async (req, res) => {
        try {

                const customizationData = await customizationModel.findOne({});

                const directoryPath = path.join(__dirname,"../../recforms");
                const files = fs.readdirSync(directoryPath);
                const requiredFile = files.filter(file => file.startsWith(`${customizationData.notEligiblePDF}`))[0];
                const filePath = path.join(__dirname,"../../recforms", requiredFile);
                console.log(filePath)
                res.download(filePath, requiredFile, (err) => {
                        if (err) {
                                console.error('Error downloading the file:', err);
                                res.status(500).send('Error downloading the file.');
                        }
                });
        } catch (error) {
                console.log(error);
                res.status(500).json({ success: false, error });
        }
})

router.post("/noteleg-info-submit", async (req, res) => {
        try {
		const customizationData = await customizationModel.findOne({});

                const directoryPath = path.join(__dirname,"../../recforms");
                const files = fs.readdirSync(directoryPath);
                const requiredFile = files.filter(file => file.startsWith(`${customizationData.notEligiblePDF}`))[0];
                const filePath = path.join(__dirname,"../../recforms", requiredFile);

		const transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
                user: `${process.env.SMTP_MAIL}`, // generated user
                pass: `${process.env.SMTP_MAIL_PSWD}`  // generated password
        }
});
const ip = "https://orders.newdaydiagnostics.com/" //change this when you change the ip address


const mailOptions = {
        from: 'info@newdaydiagnostics.com',
        to: req.body.email,
        subject: 'Welcome to New Day Diagnostics!',
        attachments: [
                {
                        filename: `ColoHealth_Eligibility_Information.pdf`, // The name of the attachment file
                        path: filePath
                }
        ],
        html:`<table
	style="border-collapse:collapse;font-family:Arial,sans-serif;font-weight:normal;margin:0px auto;max-width:600px;width:100%"
	border="0" width="100%" cellspacing="0" cellpadding="0" align="center">
	<tbody>
		<tr>
			<td style="border-collapse:collapse">
				<span>
					<table
						style="border-collapse:collapse;font-family:Roboto,arial;font-weight:normal;margin:0px auto;max-width:600px;width:100%"
						width="100%" cellspacing="0" cellpadding="0" align="center">
						<tbody>
							<tr>
								<td style="border-collapse:collapse;font-size:0px;padding:32px 5px 28px;text-align:center"
									align="center">
									<div style="display:inline-block;float:left;max-width:290px;vertical-align:top;width:100%">
										<table style="border-collapse:collapse;font-family:Roboto,arial;font-weight:normal" width="100%"
											cellspacing="0" cellpadding="0">
											<tbody>
												<tr>
													<td style="border-collapse:collapse;font-size:15px;padding:2px 0px 0px">
														<table style="border-collapse:collapse;font-family:roboto,arial;font-weight:500;width:100%"
															border="0" width="100%" cellspacing="0" cellpadding="0">
															<tbody>
																<tr>
																	<td style="border-collapse:collapse;text-align:left"><img
																			style="height:auto;outline:none;text-decoration:none"
																			src="${ip}/static/mailLoginIcon.svg" alt="logo " width="50" height="auto"
																			class="CToWUd" data-bit="iit">
																		<figcaption>New Day Diagnostics</figcaption>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</div>
									<div style="display:inline-block;float:right;max-width:290px;vertical-align:top;width:100%">
										<table style="border-collapse:collapse;font-family:Roboto,arial;font-weight:normal" width="100%"
											cellspacing="0" cellpadding="0">
											<tbody>
												<tr>
													<td style="border-collapse:collapse;font-size:15px;padding:10px 0px 0px">
														<table style="border-collapse:collapse;font-family:roboto,arial;font-weight:500;width:100%"
															border="0" width="100%" cellspacing="0" cellpadding="0">
															<tbody>
																<tr>
																	<td style="border-collapse:collapse;padding-right:0px;padding-top:0px">
																		<table
																			style="border-collapse:collapse;font-family:roboto,arial;font-weight:500;width:100%"
																			border="0" width="100%" cellspacing="0" cellpadding="0">
																			<tbody>
																				<tr>
																					<td
																						style="border-collapse:collapse;color:rgb(144,164,174);font-family:Roboto,arial;font-size:15px;font-weight:bold;line-height:16px;text-align:right"
																						align="right" width="100%"><a
																							style="color:rgb(0,0,0);font-family:Roboto,arial;font-size:18px;font-weight:700;line-height:16px;text-decoration:none"
																							href="https://emailssignature.com" rel="noopener" target="_blank"
																							data-saferedirecturl="https://www.google.com/url?q=https://emailssignature.com&amp;source=gmail&amp;ust=1700029623404000&amp;usg=AOvVaw3GmZFuNorLZ1Vr1ikcRs9u">ColoHealth</a>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</div>
								</td>
							</tr>
						</tbody>
					</table>
				</span>
				<table
					style="border-collapse:collapse;border-left:1px solid rgb(221,221,221);border-right:1px solid rgb(221,221,221);border-top:1px solid rgb(221,221,221);font-family:Arial,sans-serif;font-weight:normal;max-width:600px;width:100%;background-color:rgb(255,255,255)"
					border="0" width="100%" cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
					<tbody>
						<tr>
							<td style="border-collapse:collapse">
								<table style="background:linear-gradient(45deg, #0C1F8F 0%, #0C1F8F 35%, #ED683E 35%, #ED683E 40%, #38B7FE 40%);max-width:600px;border-collapse:collapse;width:100%" border="0"
									width="600" cellspacing="0" cellpadding="0">
									<tbody>
										<tr>
											<td style="max-width:600px;border-collapse:collapse;font-size:16px;padding-right:40px"
												align="left" width="600">
												<span>
													<table style="max-width:600px;border-collapse:collapse;width:100%"
														border="0" width="600" cellspacing="0" cellpadding="0">
														<tbody>
															<tr>
																<td
																	style="max-width:69px;padding-right:12px;padding-left:40px;border-collapse:collapse;padding-top:37px"
																	align="left" width="69"><img style="outline:none;text-decoration:none"
																		src="https://ci6.googleusercontent.com/proxy/c0ae1pHN2D5fZXqAEQywogYhm0u47xu3Ug_yWDvpIIefHp_hSpPLG9enPt24Wgyqx3GxsHnWStIKNZZIpUheM2h7vtHQx5guBqvJm7cEHDUO4urWvvDQnHzPiMnulfbB1Q=s0-d-e1-ft#http://services.google.com/fh/files/emails/hero_icon_project_reinstatement.png"
																		alt="Notification" width="17" height="18" class="CToWUd" data-bit="iit"></td>
																<td
																	style="width:100%;max-width:531px;font-family:Roboto,arial;font-weight:500;font-size:14px;color:rgb(255,255,255);letter-spacing:0.6px;border-collapse:collapse;padding-top:33px"
																	align="left" width="531">More Information Regarding ColoHealth
																</td>
															</tr>
														</tbody>
													</table>
												</span>
												<table
													style="max-width:600px;border-collapse:collapse;width:100%;font-family:Roboto,arial;font-weight:500;color:rgb(255,255,255);line-height:32px;font-size:24px"
													border="0" width="600" cellspacing="0" cellpadding="0">
													<tbody>
														<tr>
															<td
																style="width:100%;max-width:531px;border-collapse:collapse;font-family:Roboto,arial;font-weight:500;color:rgb(255,255,255);line-height:32px;font-size:24px;padding:13px 12px 24px 40px"
																align="left" width="531">&nbsp; Welcome to New Day Diagnostics!</td>
														</tr>
													</tbody>
												</table>
											</td>
										</tr>
									</tbody>
								</table>
								<div style="background-color: #DEA52B;height: 5px;"></div>
								<table
									style="max-width:600px;border-collapse:collapse;font-family:Arial,sans-serif;font-weight:normal;width:100%"
									border="0" width="600" cellspacing="0" cellpadding="0">
									<tbody>
										<tr>
											<td style="width:100%;max-width:520px;padding-top:25px;padding-left:40px;padding-right:40px"
												width="520">
												<table
													style="max-width:520px;border-collapse:collapse;font-family:Arial,sans-serif;font-weight:normal;width:100%"
													border="0" width="520" cellspacing="0" cellpadding="0">
													<tbody>
														<tr>
															<td
																style="padding-bottom:16px;font-family:Roboto,arial;font-weight:normal;font-size:14px;color:rgb(69,90,100);line-height:24px">
																Hey ${req.body.name}!</td>
														</tr>
														<tr>
															<td style="padding-bottom:16px;font-family:Roboto,arial;font-size:14px;line-height:24px">
																<p style="font-weight: bold;">You weren't eligible for the coloHealth product. You dont need to worry, just refer to he attached documents and consult with your doctor if you have concerns.</p>
																<p>Welcome to New Day Diagnostics! We are delighted to have you join our community dedicated to proactive and accessible healthcare. <br>
																</p>

																<p style="font-weight: bold;">Attached to this email, you will find:</p>

																<p>
																	A PDF to shed some more light on how the coloHealth testing works, and how your eligibility is determined. This document provides a comprehensive overview of our services and how to get started.
																</p> 

																<p>
																	<span style="font-weight: bold;"> Need Help?</span><br>

																	If you encounter any issues or need further assistance, don't hesitate to reach out to
																	our support team at .<br>

																	Once again, thanks for being a part of our community. We appreciate your trust
																	and are here to help you every step of the way.<br>

																</p>
																<p style="color:rgb(69,90,100);font-weight:normal"><span style="color:rgb(52,152,219)">

																	</span></p>
															</td>
														</tr>
													</tbody>
												</table>
											</td>
										</tr>
									</tbody>
								</table>
								<span>
									<table style="border-collapse:collapse;font-family:Arial,sans-serif;font-weight:normal" border="0"
										width="100%" cellspacing="0" cellpadding="0">
										<tbody>
											<tr>
												<td
													style="border-bottom:1px solid rgb(221,221,221);border-collapse:collapse;padding-left:40px;width:100%;padding-right:22px"
													width="100%">
													<table style="border-collapse:collapse;font-family:Arial,sans-serif;font-weight:normal"
														border="0" cellspacing="0" cellpadding="0">
														<tbody>
															<tr>
																<td
																	style="border-collapse:collapse;color:rgb(69,90,100);font-family:Roboto,arial;font-size:14px;font-weight:normal;line-height:24px;padding-bottom:7px;padding-top:14px">
																	Warm Regards,</td>
															</tr>
															<tr>
																<td
																	style="border-collapse:collapse;color:rgb(69,90,100);font-family:Roboto,arial;font-size:16px;font-weight:700;line-height:24px;padding-bottom:20px">
																	New Day Diagnostics Team</td>
															</tr>
														</tbody>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</span>
							</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
		<tr>
			<td style="border-collapse:collapse">
				<table
					style="border-collapse:collapse;font-family:Arial,sans-serif;font-weight:normal;margin:0px auto;max-width:600px;width:100%"
					border="0" width="100%" cellspacing="0" cellpadding="0" align="center">
					<tbody>
						<tr>
							<td
								style="border-collapse:collapse;color:rgb(117,117,117);font-family:Roboto,arial;font-size:12px;line-height:16px;padding:36px 40px 0px;text-align:center"
								align="center"><img style="outline:none;text-decoration:none" src="${ip}/static/mailLoginIcon.svg"
									alt="your branding here" width="50" class="CToWUd" data-bit="iit">
								<span style="display: block;color: #000;font-weight: 600;">© ${new Date().getFullYear()}&nbsp; New Day Diagnostics</span>
							</td>
						</tr>
						<tr>
							<td
								style="border-collapse:collapse;color:rgb(117,117,117);font-family:Roboto,arial;font-size:12px;line-height:16px;padding:10px 40px 20px;text-align:center"
								align="center">You have received this mandatory service announcement to update you about important
								changes/actions to your New Day Diagnostics provider account. <br>All Rights Reserved.</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
	</tbody>
</table>`
}

transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
                console.error(error);
        } else {
                log('Email sent: ' + info.response);
        }
});
	res.status(200).json({success: true});

        } catch (error) {
                console.log(error);
                res.status(500).json({ success: false, error });
        }
})

router.post("/register-provider", upload.single("profileImage"), async (req, res) => {
	try {
		const { firstName, lastName, dob, email, phone, password } = req.body;
		const match = await providerModel.findOne({ email: email });
		if (match) return res.status(400).json({ success: false, msg: "Email is already registered" });
		const hash = await bcrypt.hash(password, 10);
	
		const newProvider = new providerModel({
			firstName,
			lastName,
			dob,
			email,
			phone,
			password: hash,
			accessToken: "NULL",
			joined: new Date(),
			orderCount: 0,
			profileImage: req.file.filename,
		});

		await newProvider.save();

		sendMail(email, registrationHTML(newProvider), registrationSUB)

		res.status(200).json({ success: true, msg: "User registered" });
	} catch (error) {
		console.log(error);
		res.status(500).json({ success: false, error })
	}

});

router.post("/get-orders-for-provider", async(req, res) => {
	try {
		const {providerId} = req.body;
		console.log("Gettiong orders for the provider", providerId);
		if(!providerId) return res.status(400).json({success: false, msg:"provider is required"});
		const match = await providerModel.findOne({_id: providerId});
		if(!match) return res.status(400).json({success: false, msg:"cannot find provider"});
		const orders = await testOrdersModel.find({providerId: match._id.toString(), orderConfirmation: true});
		return res.status(200).json({success: true, orders:orders.map(item => ({orderId: item.orderId, _id:item._id.toString(), firstName: item.firstName, lastName: item.lastName, dob: item.dob, testStatus: item.testStatus, testingStatusNotes: item.testingStatusNotes}))});
		
	} catch (error) {
		console.log(error);
		res.status(500).json({ success: false, error })
	}
})

router.post("/provider-login", async (req, res) => {
	try {
		console.log(req.body);
		const { email, password, rememberMe } = req.body;
		if (!email) return res.status(400).json({ success: false, msg: "Bad request, email is missing" });
		if (!password) return res.status(400).json({ success: false, msg: "Bad request, password is missing" });

		const match = await providerModel.findOne({ email: email });
		if (!match) return res.status(400).json({ success: false, msg: "Bad request, please check your email" });

		if (await bcrypt.compare(password, match.password)) {
			const accessToken = jwt.sign({ email: email, id: match._id }, process.env.JWT_ACCESS_TOKEN_SECRET, { expiresIn: '1d' });
			match.accessToken = accessToken;
			await match.save();
			return res.status(200).json({ success: true, msg: "Login success", data: { _id:match._id, firstName: match.firstName, mi: match.mi, lastName: match.lastName, dob: match.dob, email: match.email, phone: match.phone, orderCount: match.orderCount, joined: match.joined, accessToken: match.accessToken, profileImage: match.profileImage, address1: match.address1, address2: match.address2, city: match.city, state: match.state, zip: match.zip, npi: match.npi, lisProviderId: match.lisProviderId, resultContactEmail: match.resultContactEmail, } });
		} else {
			return res.status(400).json({ success: false, msg: "Bad request, please check your email and/or password" });
		}
	} catch (error) {
		console.log(error);
		res.status(500).json({ success: false, error })
	}
});


router.post("/verify", async (req, res) => {
	try {
		const { accessToken } = req.body;
		if (!accessToken) return res.status(400).json({ success: false });
		const decoded = await jwt.verify(accessToken, process.env.JWT_ACCESS_TOKEN_SECRET);
		if (decoded) {
			const match = await providerModel.findOne({ email: decoded.email });
			if (match.accessToken === accessToken) {
				res.status(200).json({ success: true });
			}
		}
	} catch (error) {
		console.log(error);
		res.status(500).json({ success: false, error });
	}
})

router.post("/password-reset", async (req, res) => {
	try {
		const { oldPassword, newPassword, newConfirmPassword, accessToken } = req.body;

		if (!accessToken) return res.status(401).json({ success: false });
		const decoded = await jwt.verify(accessToken, process.env.JWT_ACCESS_TOKEN_SECRET);
		const match = await providerModel.findOne({ email: decoded.email });
		if (!match) return res.status(401).json({ success: false });
		if (await bcrypt.compare(oldPassword, match.password)) {
			const hash = await bcrypt.hash(newPassword, 10);
			match.password = hash;
			await match.save();
			res.status(200).json({ success: true, msg: "password changed successfully" })
		} else {
			return res.status(400).json({ success: false });
		}

	} catch (error) {
		console.log(error);
		res.status(500).json({ success: false, error });
	}
})

router.get("/get-scheduled-times", async (req, res) => {
	try {
		console.log("This endpoint is called : getting scheduled times");
		const today = new Date();
		let matches = await testOrdersModel.find({}).lean();
		matches = matches.filter((item)=>{
			let dt = new Date(item.scheduledAt);
			if(dt >= today) return true;
			else return false;
		})
		const blockedTimes = matches.map(item => item.scheduledAt);
		res.status(200).json({ success: true, blockedTimes });
	} catch (error) {
		console.log(error);
		res.status(500).json({ success: false, error: error })
	}
})

router.post("clear-scheduled-time", async (req, res) => {
	// if payment failed
	// clear the scheduled time
	// on payment success add this info to the user registrations to confirm. 
})

router.post("get-provider-orders", async (req, res) => {
	// get providerId
	// get test orders where provider id matches
	// filter according to search, page, and itemsPerPage query values
	// send
})

// provider related routes

// orders will be placed only after successful payment 
// order related routes
// router.post("/place-order", verifyUserLogin, dataController.placeOrder);

// placing order by provider



module.exports = router;
