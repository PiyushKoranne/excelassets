import React from "react";

function NeedHelp() {
  return (
    <div className="need-help-call-wr z-[100] text-[20px] font-semibold shadow-xl text-black fixed bottom-[40px] right-[50px] bg-[#E6E7E8] border-[4px] border-[#DEA52B] py-[10px] px-[30px] flex flex-col items-center justify-center">
      <div className="dekstop-help-call">
        <p className="">Need Help? Call</p>
        <a href="tel:865-299-6250" className="">
          865-299-6250
        </a>
      </div>
      <div className="phone-help-call">
        <i class="fa-solid fa-phone"></i>
      </div>
    </div>
  );
}

export default NeedHelp;
