import { Document, Font, Image, Page, StyleSheet, Text, View } from "@react-pdf/renderer";


const RequisitionFormPDF = ({patientData, providerData}) => (
	<Document>
		<Page style={styles.body}>
			<View style={{ display: "flex", flexDirection: "row", alignItems:"center", justifyContent:"space-between", borderBottom: "5px solid #E48312" }}>
				<View >
					<Image
						style={styles.image}
						src="/requisition_pdf_logo.png"
					/>
				</View>
				<View style={{ display: "flex", flexDirection: "row", alignItems:"center", gap:"6px" }}>
					<Text style={{ fontSize: "11px", marginTop:"5px" }}>Accession Number</Text>
					<Text style={{ fontSize: "13px", fontWeight: "bold", marginTop: "5px", border: "1px solid #000", width:"130px", height:"20px" }}></Text>
				</View>
			</View>
			<View style={{ marginTop: "5px", border: "1px solid black" }}>
				<Text style={{ color: "white", backgroundColor: "#595959", padding: "5px", textTransform: "uppercase", textAlign: "center", fontSize: "11px" }}>Provider Information</Text>

				<View style={{ display: "flex", alignItems: "center", flexDirection: "row", justifyContent: "flex-start", }}>
					<View style={{ backgroundColor: "#F2F2F2", display: "flex", flex: 1, flexDirection: "row", gap: "3px", paddingTop: "3px", paddingHorizontal: "3px", flexWrap: "wrap" }}>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 3 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>first Name</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{providerData ? providerData.firstName: " "}</Text>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 1 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>MI</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{providerData ? providerData.mi: " "}</Text>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 3 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>last Name</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{providerData ? providerData.lastName: " "}</Text>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 3 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>phone</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{providerData ? providerData.phone: " "}</Text>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 4 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>email</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{providerData ? providerData.email: " "}</Text>
						</View>
					</View>
				</View>

				<View style={{ display: "flex", alignItems: "center", flexDirection: "row", justifyContent: "flex-start", }}>
					<View style={{ backgroundColor: "#F2F2F2", display: "flex", flex: 1, flexDirection: "row", gap: "3px", paddingTop: "3px", paddingHorizontal: "3px", flexWrap: "wrap" }}>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 4 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>address 1</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{providerData ? providerData.address1: " "}</Text>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 4 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>address 2</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{providerData ? providerData.address2: " "}</Text>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 4 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>city</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{providerData ? providerData.city: " "}</Text>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 1 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>state</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{providerData ? providerData.state: " "}</Text>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 2 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>zip</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{providerData ? providerData.zip: " "}</Text>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 2 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>LIS ID</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{providerData ? providerData.lisProviderId: " "}</Text>
						</View>


					</View>
				</View>

				<View style={{ display: "flex", alignItems: "center", flexDirection: "row", justifyContent: "flex-start", }}>
					<View style={{ backgroundColor: "#F2F2F2", display: "flex", flex: 1, flexDirection: "row", gap: "53x", padding: "10px 5px 5px 5px", flexWrap: "wrap" }}>

						<View style={{ display: "flex", flexDirection: "row", padding: "2px 5px", flex: 4 }}>
							<Text style={{ fontSize: "9px", color: "#f43f5e", textTransform: "uppercase", fontWeight: "light", flex: 1 }}>Provider</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", borderBottom: "1px solid #f43f5e", flex: 2, textAlign: "center" }}>   </Text>
						</View>

						<View style={{ display: "flex", flexDirection: "row", padding: "2px 5px", flex: 4 }}>
							<Text style={{ fontSize: "9px", color: "#f43f5e", textTransform: "uppercase", fontWeight: "light", flex: 1 }}>Date Signed</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", borderBottom: "1px solid #f43f5e", flex: 2, textAlign: "center" }}>   </Text>
						</View>

					</View>
				</View>
			</View>
			
			<View style={{ marginTop: "5px", border: "1px solid black" }}>
				<Text style={{ color: "white", backgroundColor: "#595959", padding: "5px", textTransform: "uppercase", textAlign: "center", fontSize: "11px" }}>Patient Information</Text>
				<View style={{ display: "flex", alignItems: "center", flexDirection: "row", justifyContent: "flex-start", }}>
					<View style={{ backgroundColor: "#F2F2F2", display: "flex", flex: 1, flexDirection: "row", gap: "3px", paddingTop: "3px", paddingHorizontal: "3px", flexWrap: "wrap" }}>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 3 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>first Name</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{patientData ? patientData.firstName : ""}</Text>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 3 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>last Name</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{patientData ? patientData.lastName : " "}</Text>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 2 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>DOB</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{patientData ? patientData.dob : " "}</Text>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 2 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>phone</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{patientData ? patientData.phone : " "}</Text>
						</View>


					</View>
				</View>

				<View style={{ display: "flex", alignItems: "center", flexDirection: "row", justifyContent: "flex-start", }}>
					<View style={{ backgroundColor: "#F2F2F2", display: "flex", flex: 1, flexDirection: "row", gap: "3px", paddingTop: "3px", paddingHorizontal: "3px", flexWrap: "wrap" }}>
						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 6 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>Address</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{patientData ? patientData.streetAddress : " "}</Text>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 2 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>city</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{patientData ? patientData.city : " "}</Text>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 1 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>state</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{patientData ? patientData.state : " "}</Text>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 3 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>zip</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{patientData ? patientData.zip : " "}</Text>
						</View>
					</View>
				</View>

				<View style={{ display: "flex", alignItems: "center", flexDirection: "row", justifyContent: "flex-start", }}>
					<View style={{ backgroundColor: "#F2F2F2", display: "flex", flex: 1, flexDirection: "row", gap: "3px", paddingTop: "3px", paddingHorizontal: "3px", flexWrap: "wrap" }}>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 4 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>email</Text>
							<Text style={{ fontSize: "9px", color: "#2271b1", marginTop: "3px" }}>{patientData ? patientData.email : " "}</Text>
						</View>



						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 3 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>gender</Text>
							<View style={{ display: "flex", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: "15px", paddingTop: "1px" }}>
								<View style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: "5px" }}>
									<View style={{ width: "9px", height: "9px", borderRadius: "50%", border: "1px solid #484848", backgroundColor: patientData ? patientData.gender === "Male" ? `#2271b1`: 'transparent': '' }}></View>
									<Text style={{ fontSize: "8px", textTransform: "capitalize", fontWeight: "light" }}>Male</Text>
								</View>
								<View style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: "5px" }}>
									<View style={{ width: "9px", height: "9px", borderRadius: "50%", border: "1px solid #484848", backgroundColor: patientData ? patientData.gender === "Female" ? `#2271b1`: 'transparent': '' }}></View>
									<Text style={{ fontSize: "8px", textTransform: "capitalize", fontWeight: "light" }}>Female</Text>
								</View>
							</View>
						</View>

						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 4 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>ethnicity</Text>
							<View style={{ display: "flex", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: "15px", paddingTop: "1px" }}>
								<View style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: "5px", marginLeft: "10px" }}>
									<View style={{ width: "9px", height: "9px", borderRadius: "50%", border: "1px solid #484848", backgroundColor: patientData ? patientData.ethnicity === "Hispanic/Latino" ? `#2271b1`: 'transparent': '' }}></View>
									<Text style={{ fontSize: "8px", textTransform: "capitalize", fontWeight: "light" }}>Hispanic/Latino</Text>
								</View>
								<View style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: "5px" }}>
									<View style={{ width: "9px", height: "9px", borderRadius: "50%", border: "1px solid #484848", backgroundColor: patientData ? patientData.ethnicity === "Not Hispanic/Latino" ? `#2271b1`: 'transparent': '' }}></View>
									<Text style={{ fontSize: "8px", textTransform: "capitalize", fontWeight: "light" }}>Not Hispanic/Latino</Text>
								</View>
							</View>
						</View>


					</View>
				</View>
				<View style={{ display: "flex", alignItems: "center", flexDirection: "row", justifyContent: "flex-start", }}>
					<View style={{ backgroundColor: "#F2F2F2", display: "flex", flex: 1, flexDirection: "row", gap: "3px", paddingVertical: "3px", paddingHorizontal: "3px", flexWrap: "wrap" }}>
						<View style={{ backgroundColor: "white", border: "1px solid black", display: "flex", flexDirection: "column", padding: "2px 5px", flex: 1 }}>
							<Text style={{ fontSize: "6px", textTransform: "uppercase", fontWeight: "light" }}>race</Text>
							<View style={{ display: "flex", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: "15px", paddingVertical: "2px" }}>
								<View style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: "5px" }}>
									<View style={{ width: "9px", height: "9px", borderRadius: "50%", border: "1px solid #484848", backgroundColor: patientData ? patientData.race === "American Indian" ? `#2271b1`: 'transparent': '' }}></View>
									<Text style={{ fontSize: "8px", textTransform: "capitalize", fontWeight: "light" }}>American Indian</Text>
								</View>
								<View style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: "5px" }}>
									<View style={{ width: "9px", height: "9px", borderRadius: "50%", border: "1px solid #484848", backgroundColor: patientData ? patientData.race === "Alaskan Native" ? `#2271b1`: 'transparent': '' }}></View>
									<Text style={{ fontSize: "8px", textTransform: "capitalize", fontWeight: "light" }}>Alaskan Native</Text>
								</View>
								<View style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: "5px" }}>
									<View style={{ width: "9px", height: "9px", borderRadius: "50%", border: "1px solid #484848",  backgroundColor: patientData ? patientData.race === "Asian" ? `#2271b1`: 'transparent': '' }}></View>
									<Text style={{ fontSize: "8px", textTransform: "capitalize", fontWeight: "light" }}>Asian</Text>
								</View>
								<View style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: "5px" }}>
									<View style={{ width: "9px", height: "9px", borderRadius: "50%", border: "1px solid #484848", backgroundColor: patientData ? patientData.race === "White" ? `#2271b1`: 'transparent': '' }}></View>
									<Text style={{ fontSize: "8px", textTransform: "capitalize", fontWeight: "light" }}>White</Text>
								</View>
								<View style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: "5px" }}>
									<View style={{ width: "9px", height: "9px", borderRadius: "50%", border: "1px solid #484848", backgroundColor: patientData ? patientData.race === "African American" ? `#2271b1`: 'transparent': '' }}></View>
									<Text style={{ fontSize: "8px", textTransform: "capitalize", fontWeight: "light" }}>African American</Text>
								</View>
								<View style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: "5px" }}>
									<View style={{ width: "9px", height: "9px", borderRadius: "50%", border: "1px solid #484848",  backgroundColor: patientData ? patientData.race === "Native Hawaiian" ? `#2271b1`: 'transparent': '' }}></View>
									<Text style={{ fontSize: "8px", textTransform: "capitalize", fontWeight: "light" }}>Native Hawaiian</Text>
								</View>
								<View style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: "5px" }}>
									<View style={{ width: "9px", height: "9px", borderRadius: "50%", border: "1px solid #484848", backgroundColor: patientData ? patientData.race === "Pacific Islander" ? `#2271b1`: 'transparent': '' }}></View>
									<Text style={{ fontSize: "8px", textTransform: "capitalize", fontWeight: "light" }}>Pacific Islander</Text>
								</View>
								<View style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: "5px" }}>
									<View style={{ width: "9px", height: "9px", borderRadius: "50%", border: "1px solid #484848", backgroundColor: patientData ? patientData.race === "Prefer Not To Say" ? `#2271b1`: 'transparent': '' }}></View>
									<Text style={{ fontSize: "8px", textTransform: "capitalize", fontWeight: "light" }}>Other</Text>
								</View>
							</View>
						</View>
					</View>
				</View>
			</View>
			
			<View style={{ marginTop: "5px", border: "1px solid black" }}>
				<Text style={{ color: "white", backgroundColor: "#595959", padding: "5px", textTransform: "uppercase", textAlign: "center", fontSize: "11px" }}>Informed Consent</Text>

				<View style={{ display: "flex", alignItems: "center", flexDirection: "row", justifyContent: "flex-start", }}>
					<View style={{ backgroundColor: "#F2F2F2", display: "flex", flex: 1, flexDirection: "column", gap: "5px", paddingTop: "5px", paddingHorizontal: "5px", flexWrap: "wrap" }}>
						<Text style={{ fontSize: "8.45px", textTransform: "uppercase", color: "rgba(0,0,0,0.85)", marginVertical: "5px" }}>
							Consenting to this test requires that you understand the following: You indemnify the ordering physician and the testing laboratory, you agree to the reporting of results to the client listed above and to your email address, you agree to followup with your own physician with your results, and you agree that we may use your sample and the following information for research purposes. Providing this extra information will provide significant information for the development of effective diagnostics
						</Text>
						<Text style={{ fontSize: "8.45px", textTransform: "uppercase", color: "rgba(0,0,0,0.85)", paddingBottom:"5px" }}>
							Please sign below if you agree and consent:
						</Text>
					</View>
				</View>

				<View style={{ display: "flex", alignItems: "center", flexDirection: "row", justifyContent: "flex-start", }}>
					<View style={{ backgroundColor: "#FFE699", display: "flex", flex: 1, flexDirection: "row", gap: "5px", padding: "6px 10px", paddingHorizontal: "5px", flexWrap: "wrap", borderTop: "1px solid black" }}>
						<Text style={{ fontSize: "10px", width: "48%" }}>Patient Signature: </Text>
						<Text style={{ fontSize: "10px", width: "48%" }}>Date Signed: </Text>
						<View style={{ height: "6px", width: "100%" }}></View>
					</View>
				</View>
			</View>

			<View style={{ marginTop: "5px", border: "1px solid black" }}>
				<Text style={{ color: "white", backgroundColor: "#595959", padding: "5px", textTransform: "uppercase", textAlign: "center", fontSize: "11px" }}>For lab use only</Text>

				<View style={{ display: "flex", alignItems: "flex-start", flexDirection: "column", justifyContent: "flex-start", padding: "3px", backgroundColor: "#F2F2F2" }}>
					<Text style={{ fontSize: "8.45px", color: "rgba(0,0,0,0.85)", paddingTop:"10px", paddingLeft:"10px" }}>
						These steps correspond to steps listed in the instruction guide. See guide for more details.
					</Text>

					<View style={{display:"flex", alignItems:"center", flexDirection:"row", justifyContent:'space-between', width:"100%",  marginTop:"3px"}}>
						<View style={{ backgroundColor: "#F2F2F2", display: "flex", flexDirection: "row", gap: "5px", alignItems:"center", paddingLeft:"10px"}}>
							<Text style={{ fontSize: "8.45px", color: "rgba(0,0,0,0.85)", }}>Collection Date</Text>
							<View style={{ width: "80px", height: "20px", backgroundColor: "#fff", border: "1px solid #000000" }}></View>
						</View>
						<View style={{ backgroundColor: "#F2F2F2", display: "flex", flexDirection: "row", gap: "5px", alignItems:"center" }}>
							<Text style={{ fontSize: "8.45px", color: "rgba(0,0,0,0.85)", }}>Tech Collecting sample (initials)</Text>
							<View style={{ width: "80px", height: "20px", backgroundColor: "#fff", border: "1px solid #000000" }}></View>
						</View>
					</View>

					<View style={{display:"flex", alignItems:"center", flexDirection:"row", justifyContent:'space-between', width:"100%",  marginTop:"3px"}}>
						<View style={{ backgroundColor: "#F2F2F2", display: "flex", flexDirection: "row", gap: "5px", alignItems:"center", paddingLeft:"10px"}}>
							<Text style={{ fontSize: "8.45px", color: "rgba(0,0,0,0.85)", }}>Collection Time</Text>
							<View style={{ width: "80px", height: "20px", backgroundColor: "#fff", border: "1px solid #000000" }}></View>
						</View>
						<View style={{ backgroundColor: "#F2F2F2", display: "flex", flexDirection: "row", gap: "5px", alignItems:"center" }}>
							<Text style={{ fontSize: "8.45px", color: "rgba(0,0,0,0.85)", }}>Tech Processing sample (initials)</Text>
							<View style={{ width: "80px", height: "20px", backgroundColor: "#fff", border: "1px solid #000000" }}></View>
						</View>
					</View>

					<View style={{display:"flex", alignItems:"center", flexDirection:"row", justifyContent:'space-between', width:"100%",  marginTop:"3px"}}>
						<View style={{ backgroundColor: "#F2F2F2", display: "flex", flexDirection: "row", gap: "5px", alignItems:"center", paddingLeft:"10px"}}>
							<Text style={{ fontSize: "8.45px", color: "rgba(0,0,0,0.85)", }}>Step 1: Time first centrifugation began</Text>
							<View style={{ width: "80px", height: "20px", backgroundColor: "#fff", border: "1px solid #000000" }}></View>
							<Text style={{ fontSize: "8.45px", color: "rgba(0,0,0,0.85)", }}>am / pm</Text>
						</View>
					</View>

					<View style={{display:"flex", alignItems:"center", flexDirection:"row", justifyContent:'space-between', width:"100%",  marginTop:"3px"}}>
						<View style={{ backgroundColor: "#F2F2F2", display: "flex", flexDirection: "row", gap: "5px", alignItems:"center", paddingLeft:"15px"}}>
							<Text style={{ fontSize: "8.45px", color: "rgba(0,0,0,0.85)", }}>Was brake disabled on centrifuge?</Text>
							<View style={{ width: "25px", height: "20px", backgroundColor: "#fff", border: "1px solid #000000" }}></View>
							<Text style={{ fontSize: "8.45px", color: "rgba(0,0,0,0.85)", }}>Yes</Text>
							<View style={{ width: "25px", height: "20px", backgroundColor: "#fff", border: "1px solid #000000" }}></View>
							<Text style={{ fontSize: "8.45px", color: "rgba(0,0,0,0.85)", }}>No</Text>
						</View>
					</View>

					<View style={{display:"flex", alignItems:"center", flexDirection:"row", justifyContent:'space-between', width:"100%",  marginTop:"3px"}}>
						<View style={{ backgroundColor: "#F2F2F2", display: "flex", flexDirection: "row", gap: "5px", alignItems:"center", paddingLeft:"10px"}}>
							<Text style={{ fontSize: "8.45px", color: "rgba(0,0,0,0.85)", }}>Step 2: Transfer plasma from blood collection tube to 15mL centrifuge tube (check when complete)</Text>
							<View style={{ width: "25px", height: "20px", backgroundColor: "#fff", border: "1px solid #000000" }}></View>
						</View>
					</View>

					<View style={{display:"flex", alignItems:"center", flexDirection:"row", justifyContent:'space-between', width:"100%",  marginTop:"3px"}}>
						<View style={{ backgroundColor: "#F2F2F2", display: "flex", flexDirection: "row", gap: "5px", alignItems:"center", paddingLeft:"10px"}}>
							<Text style={{ fontSize: "8.45px", color: "rgba(0,0,0,0.85)", }}>Step 3: Time second centrifugation began</Text>
							<View style={{ width: "80px", height: "20px", backgroundColor: "#fff", border: "1px solid #000000" }}></View>
							<Text style={{ fontSize: "8.45px", color: "rgba(0,0,0,0.85)", }}>am / pm</Text>
						</View>
					</View>

					<View style={{display:"flex", alignItems:"center", flexDirection:"row", justifyContent:'space-between', width:"100%",  marginTop:"3px"}}>
						<View style={{ backgroundColor: "#F2F2F2", display: "flex", flexDirection: "row", gap: "5px", alignItems:"center", paddingLeft:"10px"}}>
							<Text style={{ fontSize: "8.45px", color: "rgba(0,0,0,0.85)", }}>Step 4: Transfer plasma into new cryovial or centrifuge tube (check when complete)</Text>
							<View style={{ width: "25px", height: "20px", backgroundColor: "#fff", border: "1px solid #000000" }}></View>
						</View>
					</View>

					<View style={{display:"flex", alignItems:"center", flexDirection:"row", justifyContent:'space-between', width:"100%",  marginTop:"3px", paddingBottom:"10px"}}>
						<View style={{ backgroundColor: "#F2F2F2", display: "flex", flexDirection: "row", gap: "5px", alignItems:"center", paddingLeft:"10px"}}>
							<Text style={{ fontSize: "8.45px", color: "rgba(0,0,0,0.85)", }}>Step 5: <Text style={{fontWeight:"bold"}}>If couriering sample:</Text> refrigerate samples until couriered on ice packs. <Text style={{fontWeight:"bold"}}>If shipping sample:</Text> Recommend
							refrigerating sample for at least 2 hours before shipping on ice packs. (see instructions)</Text>
						</View>
					</View>

				</View>
			</View>
			
			<View style={{ marginTop: "10px", backgroundColor:"#FBC717", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:"10px" }}>
				<Text style={{fontSize:"8px", textAlign:"center"}}>New Day Diagnostics</Text>
				<Text style={{fontSize:"8px", textAlign:"center"}}>6701 Baum Drive Suite 110 Knoxville, TN 37919</Text>
				<Text style={{fontSize:"8px", textAlign:"center"}}>Toll Free (844) EDP-3938 | www.NewDayDiagnostics.com | info@NewDayDiagnostics.com</Text>
				<Text style={{fontSize:"8px", textAlign:"center"}}>Medical Laboratory Director: Dr. Melissa Chiles, MD (TN LIC# 0000039233)</Text>
				<Text style={{fontSize:"8px", textAlign:"center"}}>New Day Diagnostics is a CLIA Approved (CLIA# 44D2184836) Testing Laboratory and ISO 13845:2016 R&D and Medical Device Facility </Text>
			</View>
		</Page>
	</Document>
);

Font.register({
	family: 'Oswald',
	src: 'https://fonts.gstatic.com/s/oswald/v13/Y_TKV6o8WovbUd3m_X9aAA.ttf'
});

const styles = StyleSheet.create({
	body: {
		paddingTop: 15,
		paddingBottom: 15,
		paddingHorizontal: 35,
	},
	pdfHead: {
		display: "flex",
		alignItems: "center"
	},
	title: {
		fontSize: 24,
		textAlign: 'center',
		fontFamily: 'Oswald'
	},
	author: {
		fontSize: 12,
		textAlign: 'center',
		marginBottom: 40,
	},
	subtitle: {
		fontSize: 18,
		margin: 12,
		fontFamily: 'Oswald'
	},
	text: {
		margin: 12,
		fontSize: 14,
		textAlign: 'justify',
		fontFamily: 'Times-Roman'
	},
	image: {
		width: "150px",
	},
	header: {
		fontSize: 12,
		marginBottom: 20,
		textAlign: 'center',
		color: 'grey',
	},
	pageNumber: {
		position: 'absolute',
		fontSize: 12,
		bottom: 30,
		left: 0,
		right: 0,
		textAlign: 'center',
		color: 'grey',
	},
});


export default RequisitionFormPDF;
