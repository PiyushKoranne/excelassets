import React, {useEffect, useRef, useState} from "react";
import { Transition } from "react-transition-group";

const duration = 300;

const defaultStyle = {
	transition: `opacity ${duration}ms ease-in-out`,
	opacity: 0,
};

const transitionStyles = {
	entering: { opacity: 1 },
	entered: { opacity: 1 },
	exiting: { opacity: 0 },
	exited: { opacity: 0 },
};

function Coupon({couponData}) {
	const couponRef = useRef();
	const [inProp, setInProp] = useState(false);

	useEffect(()=>{
		setInProp(true)
	},[])

	return (
		<Transition nodeRef={couponRef} in={inProp} timeout={duration}>
			{(state) => (
					<div 
						ref={couponRef}
            style={{
              ...defaultStyle,
              ...transitionStyles[state],
            }}
					className="bg-[#F6F5F2] border-[2px] border-[#DEA52B] flex items-center 560:flex-row 320:flex-col  p-[10px]">
					<figure className="560:w-[50px] 560:h-[50px] 320:w-[65px] 320:h-[65px] ">
						<img src="/coupon-applied.png" alt="" />
					</figure>
					<div className="560:ml-[10px] 320:ml-0">
						<p className="text-[18px] font-semibold uppercase 320:mt-[10px] 420:text-center 560:text-left">{couponData.couponCode} Applied <span className="320:hidden 560:inline-block 768:hidden font-extrabold uppercase text-[#ED683E]">{couponData.couponDiscount}% OFF</span></p>
						<p className="text-[14px] mt-[4px] 320:hidden 420:block 420:text-center 560:text-left">{couponData.couponName} has been applied to avail a {couponData.couponDiscount}% discount.</p>
					</div>
					<div className="768:ml-auto 320:ml-0 560:hidden 768:block 320:text-[24px] text-[32px] font-extrabold uppercase text-[#ED683E]">{couponData.couponDiscount}% OFF</div>
				</div>
        )}
		</Transition>
		
	)
}

export default Coupon;
